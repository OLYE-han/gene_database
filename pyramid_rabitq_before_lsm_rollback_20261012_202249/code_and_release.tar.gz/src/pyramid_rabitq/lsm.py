from __future__ import annotations

import fcntl
import json
import os
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import h5py
import numpy as np
import numpy.typing as npt

from .math_utils import prepare_vectors


def _atomic_text(path: Path, value: str) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        handle.write(value)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    _fsync_directory(path.parent)


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _publish_segment(temporary: Path, destination: Path) -> None:
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, destination)
    _fsync_directory(destination.parent)


def _append_wal(path: Path, record: dict[str, object]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, separators=(",", ":")) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _filter_rows(
    equal: np.ndarray,
    ranges: np.ndarray,
    tags: tuple[tuple[int, ...], ...],
    filters: list[dict[str, object]] | None,
) -> np.ndarray:
    result: np.ndarray | None = None
    for condition in filters or []:
        field, operator = str(condition["field"]), str(condition["operator"])
        value = condition["value"]
        if field == "equal":
            column = equal
        elif field == "range":
            column = ranges
        elif field == "tags" and operator == "contains":
            current = np.fromiter(
                (int(value) in row for row in tags), dtype=bool, count=len(tags)
            )
            column = None
        else:
            raise ValueError(f"unsupported scalar filter: {field} {operator}")
        if column is not None:
            operations = {
                "==": np.equal, "<": np.less, "<=": np.less_equal,
                ">": np.greater, ">=": np.greater_equal,
            }
            if operator not in operations:
                raise ValueError(f"unsupported scalar filter: {field} {operator}")
            current = operations[operator](column, value)
        if result is None:
            result = np.asarray(current, dtype=bool)
        elif str(condition.get("logic", "and")).lower() == "or":
            result |= current
        else:
            result &= current
    return np.ones(len(equal), dtype=bool) if result is None else result


@dataclass(frozen=True)
class LSMSnapshot:
    """Immutable, materialized MVCC view of the LSM segments at one sequence."""

    snapshot_id: int
    ids: np.ndarray
    vectors: np.ndarray
    deleted: np.ndarray
    equal: np.ndarray
    ranges: np.ndarray
    tags: tuple[tuple[int, ...], ...]
    shadowed_ids: frozenset[int]
    segment_count: int

    @property
    def live_count(self) -> int:
        return int(np.count_nonzero(~self.deleted))

    def search(
        self,
        query: np.ndarray,
        top_k: int,
        metric: str,
        scalar_filters: list[dict[str, object]] | None = None,
    ) -> tuple[np.ndarray, np.ndarray, int]:
        allowed = ~self.deleted
        if scalar_filters:
            allowed &= _filter_rows(self.equal, self.ranges, self.tags, scalar_filters)
        rows = np.flatnonzero(allowed)
        if not len(rows):
            return np.empty(0, dtype=np.int64), np.empty(0, dtype=np.float32), 0
        vectors = self.vectors[rows]
        distances = (
            1.0 - vectors @ query
            if metric == "cosine"
            else np.sum((vectors - query) ** 2, axis=1)
        ).astype(np.float32)
        count = min(int(top_k), len(rows))
        selected = np.argpartition(distances, count - 1)[:count]
        order = np.lexsort((self.ids[rows[selected]], distances[selected]))
        selected = selected[order]
        return self.ids[rows[selected]], distances[selected], len(rows)


class LSMReader:
    """Loads current or historical immutable snapshots and caches materialized views."""

    def __init__(self, index_root: str | Path, dimension: int) -> None:
        self.root = Path(index_root) / "lsm"
        self.dimension = int(dimension)
        self._lock = threading.RLock()
        self._cache: dict[int, LSMSnapshot] = {}
        self._current_id = self._read_current_id()

    def _read_current_id(self) -> int:
        current = self.root / "CURRENT"
        return int(current.read_text(encoding="utf-8").strip()) if current.exists() else 0

    def reload(self) -> int:
        value = self._read_current_id()
        with self._lock:
            self._current_id = value
        return value

    @property
    def current_id(self) -> int:
        with self._lock:
            return self._current_id

    def list_snapshots(self) -> list[int]:
        directory = self.root / "snapshots"
        if not directory.exists():
            return [0]
        return [0] + sorted(int(path.stem) for path in directory.glob("*.json"))

    def acquire(self, snapshot_id: int | None = None) -> LSMSnapshot:
        with self._lock:
            selected = self._current_id if snapshot_id is None else int(snapshot_id)
            cached = self._cache.get(selected)
        if cached is not None:
            return cached
        loaded = self._load(selected)
        with self._lock:
            return self._cache.setdefault(selected, loaded)

    def _load(self, snapshot_id: int) -> LSMSnapshot:
        if snapshot_id == 0:
            return LSMSnapshot(
                0, np.empty(0, dtype=np.int64),
                np.empty((0, self.dimension), dtype=np.float32),
                np.empty(0, dtype=bool), np.empty(0, dtype=np.uint16),
                np.empty(0, dtype=np.float32), (), frozenset(), 0,
            )
        path = self.root / "snapshots" / f"{snapshot_id:020d}.json"
        if not path.exists():
            raise ValueError(f"unknown snapshot_id {snapshot_id}")
        manifest = json.loads(path.read_text(encoding="utf-8"))
        latest: dict[int, tuple[np.ndarray, bool, int, float, tuple[int, ...]]] = {}
        for segment in manifest["segments"]:
            segment_path = self.root / str(segment["path"])
            with h5py.File(segment_path, "r") as handle:
                ids = np.asarray(handle["ids"], dtype=np.int64)
                deleted = np.asarray(handle["deleted"], dtype=bool)
                vectors = np.asarray(handle["embeddings"], dtype=np.float32)
                equal = np.asarray(handle["equal"], dtype=np.uint16)
                ranges = np.asarray(handle["range"], dtype=np.float32)
                indptr = np.asarray(handle["tags_indptr"], dtype=np.int64)
                indices = np.asarray(handle["tags_indices"], dtype=np.int32)
            for row, vector_id in enumerate(ids):
                latest[int(vector_id)] = (
                    vectors[row], bool(deleted[row]), int(equal[row]), float(ranges[row]),
                    tuple(map(int, indices[indptr[row]:indptr[row + 1]])),
                )
        ordered_ids = np.fromiter(latest.keys(), dtype=np.int64, count=len(latest))
        vectors = np.empty((len(latest), self.dimension), dtype=np.float32)
        deleted = np.empty(len(latest), dtype=bool)
        equal = np.empty(len(latest), dtype=np.uint16)
        ranges = np.empty(len(latest), dtype=np.float32)
        tags: list[tuple[int, ...]] = []
        for row, value in enumerate(latest.values()):
            vectors[row], deleted[row], equal[row], ranges[row], row_tags = value
            tags.append(row_tags)
        for array in (ordered_ids, vectors, deleted, equal, ranges):
            array.flags.writeable = False
        return LSMSnapshot(
            snapshot_id, ordered_ids, vectors, deleted, equal, ranges, tuple(tags),
            frozenset(map(int, ordered_ids)), len(manifest["segments"]),
        )


class LSMStore:
    """WAL-backed immutable-segment writer with snapshot manifests."""

    def __init__(self, index_root: str | Path, dimension: int, metric: str) -> None:
        self.root = Path(index_root) / "lsm"
        self.dimension = int(dimension)
        self.metric = str(metric)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "segments").mkdir(exist_ok=True)
        (self.root / "snapshots").mkdir(exist_ok=True)
        (self.root / "LOCK").touch(exist_ok=True)
        (self.root / "WAL.jsonl").touch(exist_ok=True)
        if not (self.root / "CURRENT").exists():
            _atomic_text(self.root / "CURRENT", "0\n")

    @contextmanager
    def _writer_lock(self) -> Iterator[None]:
        with (self.root / "LOCK").open("r+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def current_id(self) -> int:
        return int((self.root / "CURRENT").read_text(encoding="utf-8").strip())

    @staticmethod
    def _tag_csr(tags: list[list[int]] | tuple[tuple[int, ...], ...], rows: int):
        if len(tags) != rows:
            raise ValueError("tags length differs from ids")
        lengths = np.fromiter((len(value) for value in tags), dtype=np.int64, count=rows)
        indptr = np.concatenate(([0], np.cumsum(lengths))).astype(np.int64)
        indices = (
            np.concatenate([np.asarray(value, dtype=np.int32) for value in tags])
            if int(indptr[-1]) else np.empty(0, dtype=np.int32)
        )
        return indptr, indices

    def commit_upserts(
        self,
        ids: npt.ArrayLike,
        vectors: npt.ArrayLike,
        *,
        equal: npt.ArrayLike | None = None,
        ranges: npt.ArrayLike | None = None,
        tags: list[list[int]] | tuple[tuple[int, ...], ...] | None = None,
    ) -> int:
        ids_array = np.asarray(ids, dtype=np.int64)
        if ids_array.ndim != 1 or len(np.unique(ids_array)) != len(ids_array):
            raise ValueError("ids must be a one-dimensional unique array")
        prepared = prepare_vectors(vectors, self.metric)
        if prepared.shape != (len(ids_array), self.dimension):
            raise ValueError(f"vectors must have shape ({len(ids_array)}, {self.dimension})")
        equal_array = np.zeros(len(ids_array), dtype=np.uint16) if equal is None else np.asarray(equal, dtype=np.uint16)
        range_array = np.zeros(len(ids_array), dtype=np.float32) if ranges is None else np.asarray(ranges, dtype=np.float32)
        if equal_array.shape != ids_array.shape or range_array.shape != ids_array.shape:
            raise ValueError("scalar metadata length differs from ids")
        row_tags = tags if tags is not None else [[] for _ in ids_array]
        return self._commit(ids_array, prepared, np.zeros(len(ids_array), dtype=bool), equal_array, range_array, row_tags)

    def commit_deletes(self, ids: npt.ArrayLike) -> int:
        ids_array = np.asarray(ids, dtype=np.int64)
        if ids_array.ndim != 1 or len(np.unique(ids_array)) != len(ids_array):
            raise ValueError("ids must be a one-dimensional unique array")
        return self._commit(
            ids_array, np.zeros((len(ids_array), self.dimension), dtype=np.float32),
            np.ones(len(ids_array), dtype=bool), np.zeros(len(ids_array), dtype=np.uint16),
            np.zeros(len(ids_array), dtype=np.float32), [[] for _ in ids_array],
        )

    def _commit(self, ids, vectors, deleted, equal, ranges, tags) -> int:
        if not len(ids):
            return self.current_id()
        with self._writer_lock():
            parent = self.current_id()
            sequence = parent + 1
            transaction = uuid.uuid4().hex
            _append_wal(self.root / "WAL.jsonl", {
                "event": "begin", "tx": transaction, "sequence": sequence,
                "parent": parent, "time_ns": time.time_ns(),
            })
            relative = Path("segments") / f"segment-{sequence:020d}-{transaction}.h5"
            destination = self.root / relative
            temporary = destination.with_suffix(".tmp.h5")
            indptr, indices = self._tag_csr(tags, len(ids))
            with h5py.File(temporary, "w") as handle:
                handle.attrs["sequence"] = sequence
                handle.attrs["level"] = 0
                handle.create_dataset("ids", data=ids)
                handle.create_dataset("deleted", data=deleted)
                handle.create_dataset("embeddings", data=vectors)
                handle.create_dataset("equal", data=equal)
                handle.create_dataset("range", data=ranges)
                handle.create_dataset("tags_indptr", data=indptr)
                handle.create_dataset("tags_indices", data=indices)
                handle.flush()
            _publish_segment(temporary, destination)
            previous_segments: list[dict[str, object]] = []
            if parent:
                previous = json.loads((self.root / "snapshots" / f"{parent:020d}.json").read_text(encoding="utf-8"))
                previous_segments = list(previous["segments"])
            manifest = {
                "format_version": 1, "snapshot_id": sequence, "parent": parent,
                "created_at_ns": time.time_ns(),
                "segments": previous_segments + [{"path": str(relative), "level": 0, "sequence": sequence}],
            }
            manifest_path = self.root / "snapshots" / f"{sequence:020d}.json"
            _atomic_text(manifest_path, json.dumps(manifest, indent=2) + "\n")
            _atomic_text(self.root / "CURRENT", f"{sequence}\n")
            _append_wal(self.root / "WAL.jsonl", {
                "event": "commit", "tx": transaction, "sequence": sequence,
                "time_ns": time.time_ns(),
            })
            return sequence

    def compact(self) -> int:
        """Publish one L1 segment for the current view; old files remain snapshot-readable."""
        reader = LSMReader(self.root.parent, self.dimension)
        snapshot = reader.acquire()
        if snapshot.snapshot_id == 0 or snapshot.segment_count <= 1:
            return snapshot.snapshot_id
        # Compaction is a normal snapshot commit and retains tombstones because
        # they are required to continue shadowing rows in the immutable base.
        with self._writer_lock():
            parent = self.current_id()
            if parent != snapshot.snapshot_id:
                raise RuntimeError("LSM changed during compaction; retry")
            sequence = parent + 1
            transaction = uuid.uuid4().hex
            _append_wal(self.root / "WAL.jsonl", {"event": "compact-begin", "tx": transaction, "sequence": sequence, "parent": parent})
            relative = Path("segments") / f"segment-{sequence:020d}-{transaction}-L1.h5"
            destination = self.root / relative
            temporary = destination.with_suffix(".tmp.h5")
            indptr, indices = self._tag_csr(snapshot.tags, len(snapshot.ids))
            with h5py.File(temporary, "w") as handle:
                handle.attrs["sequence"] = sequence
                handle.attrs["level"] = 1
                for name, values in (("ids", snapshot.ids), ("deleted", snapshot.deleted), ("embeddings", snapshot.vectors), ("equal", snapshot.equal), ("range", snapshot.ranges), ("tags_indptr", indptr), ("tags_indices", indices)):
                    handle.create_dataset(name, data=values)
                handle.flush()
            _publish_segment(temporary, destination)
            manifest = {"format_version": 1, "snapshot_id": sequence, "parent": parent, "created_at_ns": time.time_ns(), "segments": [{"path": str(relative), "level": 1, "sequence": sequence}]}
            _atomic_text(self.root / "snapshots" / f"{sequence:020d}.json", json.dumps(manifest, indent=2) + "\n")
            _atomic_text(self.root / "CURRENT", f"{sequence}\n")
            _append_wal(self.root / "WAL.jsonl", {"event": "compact-commit", "tx": transaction, "sequence": sequence})
            return sequence
