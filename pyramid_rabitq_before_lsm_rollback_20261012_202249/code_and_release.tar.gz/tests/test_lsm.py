from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

from pyramid_rabitq.lsm import LSMReader, LSMStore


class LSMTests(unittest.TestCase):
    def test_snapshot_update_delete_restart_and_compaction(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = LSMStore(root, dimension=2, metric="l2")
            first = store.commit_upserts(
                [7, 8], [[1.0, 0.0], [4.0, 0.0]],
                equal=[1, 2], ranges=[0.1, 0.2], tags=[[3], [4, 5]],
            )
            second = store.commit_upserts(
                [7], [[9.0, 0.0]], equal=[9], ranges=[0.9], tags=[[10]]
            )
            third = store.commit_deletes([8])
            self.assertEqual((first, second, third), (1, 2, 3))

            # A reader pins old snapshots even after later commits.
            restarted = LSMReader(root, dimension=2)
            old = restarted.acquire(first)
            current = restarted.acquire()
            self.assertEqual(old.shadowed_ids, {7, 8})
            self.assertEqual(old.live_count, 2)
            old_ids, _, _ = old.search(np.array([1.0, 0.0]), 2, "l2")
            self.assertEqual(old_ids.tolist(), [7, 8])
            self.assertEqual(current.live_count, 1)
            ids, _, _ = current.search(np.array([9.0, 0.0]), 2, "l2")
            self.assertEqual(ids.tolist(), [7])

            compacted = store.compact()
            self.assertEqual(compacted, 4)
            after = LSMReader(root, dimension=2).acquire()
            self.assertEqual(after.segment_count, 1)
            self.assertEqual(after.shadowed_ids, current.shadowed_ids)
            ids, _, _ = after.search(np.array([9.0, 0.0]), 2, "l2")
            self.assertEqual(ids.tolist(), [7])
            # Historical snapshot files and their segments remain readable.
            self.assertEqual(LSMReader(root, 2).acquire(first).live_count, 2)

    def test_filters_and_cosine_normalization(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = LSMStore(root, dimension=2, metric="cosine")
            store.commit_upserts(
                [1, 2], [[10.0, 0.0], [0.0, 5.0]],
                equal=[3, 4], ranges=[10.0, 20.0], tags=[[7], [8]],
            )
            snapshot = LSMReader(root, 2).acquire()
            ids, _, candidates = snapshot.search(
                np.array([1.0, 0.0], dtype=np.float32), 10, "cosine",
                [{"field": "tags", "operator": "contains", "value": 7}],
            )
            self.assertEqual(ids.tolist(), [1])
            self.assertEqual(candidates, 1)


if __name__ == "__main__":
    unittest.main()
